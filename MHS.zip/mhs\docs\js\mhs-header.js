// docs/js/mhs-header.js
// Move the page's .toggle-bar into the Material header as a second row.
// Keeps desktop right alignment and mobile left alignment via CSS only.

(function () {
  const LOG = '[mhs-header]';

  function moveToolbar() {
    const header = document.querySelector('.md-header');
    if (!header) { console.log(LOG, 'no .md-header'); return false; }

    // Prefer the inner container when present (Material wraps content here)
    const inner = header.querySelector('.md-header__inner') || header;

    // Already added?
    if (inner.querySelector('.mhs-toolbar')) {
      console.log(LOG, 'toolbar already present');
      return true;
    }

    // Find the page-rendered toggle bar
    const bar = document.querySelector('.toggle-bar');
    if (!bar) { 
      console.log(LOG, 'no .toggle-bar found in page'); 
      return false; 
    }

    // Make a new row and move the bar into it
    const row = document.createElement('div');
    row.className = 'mhs-toolbar';
    row.appendChild(bar);

    // Append as the last child so it sits under the title row
    inner.appendChild(row);

    // Let CSS adjust layout only when toolbar exists
    document.body.classList.add('mhs-has-toolbar');

    console.log(LOG, 'moved .toggle-bar into header');
    return true;
  }

  // Try on DOM ready; retry briefly if content hydrates late
  document.addEventListener('DOMContentLoaded', () => {
    if (moveToolbar()) return;
    let tries = 0;
    const t = setInterval(() => {
      tries++;
      if (moveToolbar() || tries > 30) clearInterval(t);
    }, 120);
  });

  // If MkDocs swaps page content (instant navigation), re-attach
  const root = document.querySelector('[data-md-component="content"]') || document.body;
  const mo = new MutationObserver(() => {
    if (!document.querySelector('.mhs-toolbar') && document.querySelector('.toggle-bar')) {
      moveToolbar();
    }
  });
  mo.observe(root, { childList: true, subtree: true });
})();
