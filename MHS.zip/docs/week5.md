# Miért [[tanul tok]] [[magyar ul]]?
##### Why are you learning Hungarian? (past tense; B1 level)

{{ render_phrases("week5") }}

<!-- https://www.reddit.com/r/hungarian/comments/1nrpn6p/mi%C3%A9rt_tanultok_magyarul_an_unscientific_poll/ -->